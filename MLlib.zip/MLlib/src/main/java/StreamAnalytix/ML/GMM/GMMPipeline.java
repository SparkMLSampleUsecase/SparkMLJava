package SampleML.ML.GMM;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.ml.Pipeline;
import org.apache.spark.ml.PipelineStage;
import org.apache.spark.ml.clustering.GaussianMixture;
import org.apache.spark.ml.clustering.GaussianMixtureModel;
import org.apache.spark.ml.feature.MaxAbsScaler;
import org.apache.spark.ml.feature.QuantileDiscretizer;
import org.apache.spark.ml.feature.VectorAssembler;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.json.JSONObject;

public class GMMPipeline {
    /** Pipeline preparation and execution
     * 
     * @param session
     * @param inputDocs
     * @throws IOException */
    public static void executer(SparkSession session, String[] inputDocs) throws IOException {
        JavaSparkContext jsc = JavaSparkContext.fromSparkContext(session.sparkContext());
        Dataset<Row> countrydataSet = session.sqlContext().read().format("com.databricks.spark.csv").option("header", true).load(inputDocs[0]);
        Dataset<Row> continentdataSet = session.sqlContext().read().format("com.databricks.spark.csv").option("header", true).load(inputDocs[1]);
        Dataset<Row> joinedData = countrydataSet.join(continentdataSet, "Country");
        //Schema creation 
        Dataset<Row> finalDataSet = joinedData
                .withColumn("Area_in_km_sqr",new Column("Area_in_km_sqr").cast(DataTypes.DoubleType))
                .withColumn("Names_per_km_sqr",new Column("Names_per_km_sqr").cast(DataTypes.DoubleType))
                .withColumn("Population",new Column("Population").cast(DataTypes.DoubleType))
                .withColumn("Names_per_1000_Inhabitants",new Column("Names_per_1000_Inhabitants").cast(DataTypes.DoubleType))
                .withColumn("Continent",new Column("Continent"))
                .withColumn("CountryCode", new Column("CountryCode"))
                .withColumn("Country", new Column("Country"));
        Dataset<Row> selectedData = finalDataSet.select("Area_in_km_sqr","Population");
        final List<String> clusteringCols = new ArrayList<String>();
        clusteringCols.add("Area_in_km_sqr");
        clusteringCols.add("Population");
        final List<PipelineStage> stages = new ArrayList<PipelineStage>();
        for (String col : clusteringCols) {
            QuantileDiscretizer quantileDiscretizer = new QuantileDiscretizer().setInputCol(col).setOutputCol(col + "_bucketd").setNumBuckets(10);
            stages.add(quantileDiscretizer);
        }
        final List<String> assmbelList = new ArrayList<String>();
        assmbelList.add("Area_in_km_sqr_bucketd");
        assmbelList.add("Population_bucketd");
        VectorAssembler assembler = new VectorAssembler();
        assembler.setInputCols(assmbelList.toArray(new String[assmbelList.size()])).setOutputCol("feature");
        stages.add(assembler);
        MaxAbsScaler scaler = new MaxAbsScaler()
                .setInputCol("feature")
                .setOutputCol("scaledFeatures");
        stages.add(scaler);
        GaussianMixture gmm = new GaussianMixture().setK(4).setMaxIter(10).setFeaturesCol("scaledFeatures").setPredictionCol("prediction");
        stages.add(gmm);
        Pipeline pipeline = new Pipeline().setStages(stages.toArray(new PipelineStage[stages.size()]));
        pipeline.fit(selectedData).transform(selectedData).show(true);
        List<Row> groupCoordinates= pipeline.fit(selectedData).transform(selectedData).select("scaledFeatures","prediction").toJavaRDD().collect();
        JSONObject obj = null;
        List<JSONObject> jsonData = new ArrayList<JSONObject>();
        System.out.println("X,Y");
        int cent = 0;
        Map<String, String> datapoints = null;
        Map<String, List<Map>> dataMap = new HashMap<String, List<Map>>();
        List<Map> dataListMap = new ArrayList<Map>();
        for (Row grpCordi : groupCoordinates) {
            String[] coordi = (grpCordi.get(0).toString().replace("[", "").replace("]", "")).split(",");
            // System.out.println("X : " +coordi[0]+ " Y :" +coordi[1]+" Cluster :" +grpCordi.get(1).toString());
            if (null != dataMap.get(grpCordi.get(1).toString())) {
                dataListMap = dataMap.get(grpCordi.get(1).toString());
            }
            datapoints = new HashMap<String, String>();
            datapoints.put("X", coordi[0]);
            datapoints.put("Y", coordi[1]);
            dataListMap.add(datapoints);
            dataMap.put(grpCordi.get(1).toString(), dataListMap);
            
            // System.out.println("["+coordi[0]+ "," +coordi[1]+"]");
        }
        for(int cnt=0; cnt < dataMap.size(); cnt++){
            
            obj = new JSONObject();
            String clusterNumber =new Integer(cnt).toString();
            obj.put("cluster", clusterNumber);
            obj.put("data_coordinates", dataMap.get(clusterNumber));
            jsonData.add(obj);
        }
        for (JSONObject json : jsonData) {
            System.out.println(json);
        }
        pipeline.fit(finalDataSet).save("/home/shashank/SparkMLlib/Output/pipeline/GMM/"+4);
        //Column col = new Column("feature");
        //GaussianMixtureModel model = gmm.fit(pipeline.fit(finalDataSet).transform(finalDataSet).select("feature"));
        //model.save("/home/shashank/SparkMLlib/Output/pipeline/GMM/"+1);
        // Output the parameters of the mixture model
        /*for (int i = 0; i < model.getK(); i++) {
          System.out.printf("Gaussian %d:\nweight=%f\nmu=%s\nsigma=\n%s\n\n",
                  i, model.weights()[i], model.gaussians()[i].mean(), model.gaussians()[i].cov());
        }*/
        // $example off$
        jsc.stop();
    }
    public static void main(String[] args) throws IOException {
        args = new String[3];
        args[0] = "/home/shashank/SparkMLlib/Input/GMM_input/Countrydata.csv";
        args[1] = "/home/shashank/SparkMLlib/Input/GMM_input/Countries-Continents.csv";
        SparkSession session = SparkSession.builder().appName("GMMPipeline").master("local").getOrCreate();
        executer(session, args);

    }

}
