package SampleML.ML.RandomForest;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.spark.ml.regression.RandomForestRegressionModel;
import org.apache.spark.ml.tree.CategoricalSplit;
import org.apache.spark.ml.tree.ContinuousSplit;
import org.apache.spark.ml.tree.DecisionTreeModel;
import org.apache.spark.ml.tree.InternalNode;
import org.apache.spark.ml.tree.LeafNode;
import org.apache.spark.ml.tree.Node;
import org.apache.spark.ml.tree.Split;

import SampleML.ML.test.MLlibConstants;

public class RFRVisulazior {


    @SuppressWarnings("unchecked")  
    public Map<String, Object> getTreeModelDetails(Object model, Map<String,Object> json) throws Throwable {     
        Map<String, Object> uiJson = new LinkedHashMap<String, Object>();


        try {

            List<String> modelFields = new ArrayList<String>(((Map<String, Object>) json.get(MLlibConstants.CATEGORICAL_VARIABLES)).keySet().size()+((List<String>) json.get(MLlibConstants.CONTINUOUS_VARIABLES)).size());   // list to contain names of model's continuous and categorical variables
            Map<String, Object> categoricalMap = (Map<String, Object>) json.get(MLlibConstants.CATEGORICAL_VARIABLES); // map contains categorical

            if (json.get(MLlibConstants.CONTINUOUS_VARIABLES) != null) {
                modelFields.addAll((List<String>) json.get(MLlibConstants.CONTINUOUS_VARIABLES));
            }
            if (json.get(MLlibConstants.CATEGORICAL_VARIABLES) != null) {
                modelFields.addAll(((Map<String, Object>) json.get(MLlibConstants.CATEGORICAL_VARIABLES)).keySet());
            }

            if (model instanceof RandomForestRegressionModel ) {
                RandomForestRegressionModel rfrModel = (RandomForestRegressionModel) model; // cast model to GBTClassificationModel
                double[] treeWeights = rfrModel.treeWeights(); 

                for (int i = 0; i <rfrModel.trees().length; i++) {
                    DecisionTreeModel dtm = rfrModel.trees()[i];    

                    uiJson.put(MLlibConstants.TREE+i,getTree(dtm.rootNode(),dtm.rootNode(),true,modelFields,categoricalMap,dtm.depth(),treeWeights[i]));

                }
                return uiJson;
            }

        } catch (Exception e) {
            throw new Exception(e); 

        }
        return uiJson;
    }

    private LinkedHashMap<String, Object> getTree(Node pNode, Node node, boolean isLeftNode, List<String> modelFields,          
            Map<String, Object> categoricalMap, int depth, Double weight) throws Throwable {
        
                
        LinkedHashMap<String, Object> nodeDetails = new LinkedHashMap<String, Object>();
        LinkedHashMap<String, Object> nodesMap = new LinkedHashMap<String, Object>();
        // nodeDetails.put(MLlibConstants.ID, node.hashCode());
        nodeDetails.put(MLlibConstants.IMPURITY, Math.round(node.impurity()/MLlibConstants.HUNDRED)
                + MLlibConstants.PERCENTAGE); // converted impurity into percentage
        nodeDetails.put(MLlibConstants.SCORE, Math.round(node.prediction() * MLlibConstants.TEN_THOUSAND));
        // MLlibConstants.TEN_THOUSAND); // limit
        // score
        // to
        // four
        // decimal
        // places

        // nodeDetails.put(MLlibConstants.PROBABILITY, node.prediction());
        if(node.subtreeDepth() == 0)        
            nodeDetails.put(MLlibConstants.IS_LEAF_NODE,true);
        else
            nodeDetails.put(MLlibConstants.IS_LEAF_NODE,false);

        if (node.equals(pNode)) { // if node is root node
            nodeDetails.put(MLlibConstants.PARENT, MLlibConstants.EMPTY_STRING);
            nodeDetails.put(MLlibConstants.RULE, MLlibConstants.EMPTY_STRING);
            nodeDetails.put(MLlibConstants.TREE_DEPTH, depth);
            if (weight != null) {
                nodeDetails.put(MLlibConstants.WEIGHT, weight);
            }
        } else {
            nodeDetails.put(MLlibConstants.PARENT, pNode);
            nodeDetails.put(MLlibConstants.RULE, getRule((InternalNode)pNode, isLeftNode, modelFields, categoricalMap));
        }

        if (node.subtreeDepth() != 0) {
            List<LinkedHashMap<String, Object>> children = new ArrayList<LinkedHashMap<String, Object>>();
            if(node instanceof InternalNode){
                InternalNode iNode = (InternalNode)node;


                if(node instanceof LeafNode){
                    System.out.println("leaf Node");
                }

                children.add(getTree(node, iNode.leftChild(), true, modelFields, categoricalMap, depth, weight));
                children.add(getTree(node, iNode.rightChild(), false, modelFields, categoricalMap, depth, weight));
                nodeDetails.put(MLlibConstants.CHILDREN, children);
            }

        }



        nodesMap.putAll(nodeDetails);
        return nodesMap;
    }

    private static String getRule(InternalNode parentNode, boolean left, List<String> modelFields, Map<String, Object> categoricalMap) {

        
        Split split = parentNode.split();
        String splitFieldName = modelFields.get(split.featureIndex());

        if (split instanceof ContinuousSplit) { // create rule expression for continuous variable and replace feature index with

            ContinuousSplit cSplit = (ContinuousSplit)split;                                  // feature name from modelFields list
            if (left) {
                return splitFieldName + MLlibConstants.LESS_THAN_EQUAL_TO + cSplit.threshold();
            } else {
                return splitFieldName + MLlibConstants.GREATER_THAN + cSplit.threshold();
            }
        } else if (split instanceof CategoricalSplit) { // create rule expression for categorical variable and replace feature
            CategoricalSplit catSplit = (CategoricalSplit)split;                                                              // index with feature name from modelFields list

            List<String> categories = (List<String>) categoricalMap.get(splitFieldName);
            List<String> splitCategories = mkString(catSplit.leftCategories());
            merge(splitCategories,catSplit.leftCategories());
            StringBuilder categoryString = new StringBuilder();

            // Loop split categories and get name of categories for split field from categorical map
            for (int i = 0; i < splitCategories.size(); i++) {
                categoryString.append(categories.get(new Double(splitCategories.get(i)).intValue()));
                //categoryString.append(splitCategories.get(i));
                if (i != splitCategories.size() - 1) {
                    categoryString.append(", ");
                }
            }

            if (left) {
                return splitFieldName + MLlibConstants.IN + categoryString;
            } else {
                return splitFieldName + MLlibConstants.NOT_IN + categoryString;
            }
        }
        return "";

    }

    private static void merge(List<String> splitCategories, double[] categories) {
        for(double d : categories){
            splitCategories.add(Double.toString(d));    
        }   

    }

    private static List<String> mkString(double[] categories) {
        List<String> list = new ArrayList<String>();
        for(double d : categories){
            if(!list.contains(Double.toString(d)))
            {
                list.add(Double.toString(d));   
            }
        }   
        return list;
    }


}
