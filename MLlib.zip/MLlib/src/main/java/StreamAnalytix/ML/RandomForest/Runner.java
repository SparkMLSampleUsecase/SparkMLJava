package SampleML.ML.RandomForest;

import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.spark.ml.regression.RandomForestRegressionModel;
import org.apache.spark.sql.SparkSession;
import net.minidev.json.JSONObject;

import SampleML.ML.test.MLlibConstants;

public class Runner {

    static JSONObject json = new JSONObject();
	public static void main(String[] args) throws Throwable {
		
		SparkSession session = SparkSession
			      .builder()
			      .appName("RFRVisulation")
			      .master("local")
			      .getOrCreate();
	   RFRVisulazior rfrVisulazior = new RFRVisulazior();
	   RandomForestRegressionModel model = RandomForestRegressionModel.load(MLlibConstants.RFR_MODEL_PATH);
		
	   	 Map<String, Object> uiJson = rfrVisulazior.getTreeModelDetails(model, getConfig());
		 System.out.println("finish"+uiJson.size());
		// try-with-resources statement based on post comment below :)
	        try (FileWriter file = new FileWriter("/home/shashank/SparkMLlib/Output/RFR/JSON/data1.json")) {
	            file.write(json.toJSONString(uiJson));
	            System.out.println("Successfully Copied JSON Object to File...");
	            //System.out.println("\nJSON Object: " + obj);
	        }
	}
	private static void printmap(LinkedHashMap<String, Object> map) {
		for(Map.Entry<String, Object> entry: map.entrySet()){
			String key = entry.getKey();
			Object value = entry.getValue();
			
			if(value instanceof List) {
				List<LinkedHashMap<String, Object>> childrens = (List<LinkedHashMap<String, Object>>)value;
				for(LinkedHashMap<String, Object> child:childrens){
					printmap(child);
				}
			}
			
			//System.out.println("key -> "+key +" value -> "+value);
			
			}
		
		
	}

		// Preparing configuration
		private static Map<String,Object> getConfig() {

			Map<String,Object> config  = new HashMap<String,Object>();	

			List<String> continous = new ArrayList<String>();
			continous.add("age");
			continous.add("Blood_sugar");
			config.put(MLlibConstants.CONTINUOUS_VARIABLES,continous);

			HashMap<String, List<String>> categorical = new LinkedHashMap<String, List<String>>();
			List<String> catJobList = new ArrayList<String>();
			catJobList.add("management");
			catJobList.add("retired");
			catJobList.add("unknown");
			catJobList.add("self-employed");
			catJobList.add("student");
			catJobList.add("blue-collar");
			catJobList.add("entrepreneur");
			catJobList.add("admin");
			catJobList.add("technician");
			catJobList.add("services");
			catJobList.add("housemaid");
			catJobList.add("unemployed");
			List<String> catMRList = new ArrayList<String>();
			catMRList.add("divorced");
			catMRList.add("married");
			catMRList.add("single");
			categorical.put("job", catJobList);
			categorical.put("marital", catMRList);
			// nothing to add in this data set
			config.put(MLlibConstants.CATEGORICAL_VARIABLES, categorical);	
			return config;
		}

}
