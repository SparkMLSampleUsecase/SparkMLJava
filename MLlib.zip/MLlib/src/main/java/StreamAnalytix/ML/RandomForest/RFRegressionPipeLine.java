package SampleML.ML.RandomForest;

import java.util.ArrayList;
import java.util.List;

import org.apache.spark.ml.Pipeline;
import org.apache.spark.ml.PipelineModel;
import org.apache.spark.ml.PipelineStage;
import org.apache.spark.ml.evaluation.RegressionEvaluator;
import org.apache.spark.ml.feature.StringIndexer;
import org.apache.spark.ml.feature.VectorAssembler;
import org.apache.spark.ml.linalg.Vector;
import org.apache.spark.ml.linalg.Vectors;
import org.apache.spark.ml.regression.RandomForestRegressionModel;
import org.apache.spark.ml.regression.RandomForestRegressor;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;

public class RFRegressionPipeLine {

    public static void main(String[] args) throws Throwable {
      SparkSession session = SparkSession
        .builder()
        .master("local")
        .appName("RFRegerssionPipeline")
        .getOrCreate();

      // Load and parse the data file, converting it to a DataFrame.
      //Dataset<Row> data = session.sqlContext().read().format("com.databricks.spark.csv").option("header", true).load("/home/shashank/SparkMLlib/Input/predit_BS.csv");
      Dataset<Row> data = session.sqlContext().read().format("com.databricks.spark.csv").option("header", true).load("/home/shashank/SparkMLlib/Input/blood-sugar_Vsmall.csv");
      Dataset<Row> dataUp = data.withColumn("age",new Column("age").cast(DataTypes.DoubleType))
              .withColumn("Blood_suger",new Column("Blood_suger").cast(DataTypes.DoubleType))
              .withColumn("job",new Column("job").cast(DataTypes.StringType))
              .withColumn("marital",new Column("marital").cast(DataTypes.StringType));
      Dataset<Row> filteredData = dataUp.filter(new Column("job").notEqual(""));
      filteredData.select("job").distinct().show();
      filteredData.select("marital").distinct().show();
      final List<PipelineStage> pipelineStages = new ArrayList<PipelineStage>();
      
      final List<String> continuous = new ArrayList<String>();
      continuous.add("age");
      continuous.add("Blood_suger");

      List<String> categorical = new ArrayList<String>();
      
      categorical.add("job");
      categorical.add("marital");
      
      List<String> assembleList = new ArrayList<String>();
      
      for (String variable : continuous) {
          assembleList.add(variable);
      }
      
      for (String variable : categorical) {
          StringIndexer indexer = new StringIndexer().setInputCol(variable)
                  .setOutputCol(variable + "Indexer");
          assembleList.add(variable + "Indexer");
          pipelineStages.add(indexer);
      }
      
      VectorAssembler assembler = new VectorAssembler();
      assembler.setInputCols(
              assembleList.toArray(new String[assembleList.size()]))
              .setOutputCol("features");
      pipelineStages.add(assembler);
      
      RandomForestRegressor rfregg = new RandomForestRegressor()
              .setLabelCol("Blood_suger")
              .setFeaturesCol("features")
              .setPredictionCol("prediction")
              .setCacheNodeIds(true)
              .setCheckpointInterval(1)
              .setMaxBins(30)
              .setMaxDepth(28)
              .setImpurity("variance");
      pipelineStages.add(rfregg);

      Pipeline pipeline = new Pipeline();
      PipelineStage[] stages = new PipelineStage[pipelineStages.size()];
      int cnt = 0;
      for(PipelineStage stage : pipelineStages){
          stages[cnt]= stage;
          cnt++;
      }
      //pipeline.setStages(stages).fit(filteredData).transform(filteredData).show();
      PipelineModel plMdel = pipeline.setStages(stages).fit(filteredData);
      plMdel.write().overwrite().save("/home/shashank/SparkMLlib/Output/RFR/PL/3");
   // Make predictions.
      Dataset<Row> predictions = pipeline.setStages(stages).fit(filteredData).transform(filteredData);

      // Select example rows to display.
      predictions.show(5);
      
   // Select (prediction, true label) and compute test error
      RegressionEvaluator evaluator = new RegressionEvaluator()
        .setLabelCol("Blood_suger")
        .setPredictionCol("prediction")
        .setMetricName("rmse");
      double rmse = evaluator.evaluate(predictions);
      System.out.println("Root Mean Squared Error (RMSE) on test data = " + rmse);

      RandomForestRegressionModel rfModel = (RandomForestRegressionModel)(plMdel.stages()[3]);
      //System.out.println("Learned regression forest model:\n" + rfModel.toDebugString());
      //rfModel.save("/home/shashank/SparkMLlib/Output/RFR/11");
      //Testing model
      double [] vals = {60.0,0.0,11.0,9.0};
      Vector vec = Vectors.dense(vals);
      System.out.println(rfModel.predict(vec));
      session.stop();
    }

}
