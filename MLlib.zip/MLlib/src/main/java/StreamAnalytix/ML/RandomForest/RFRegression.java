package SampleML.ML.RandomForest;

import java.util.ArrayList;
import java.util.List;

import org.apache.spark.ml.PipelineStage;
import org.apache.spark.ml.feature.VectorAssembler;
import org.apache.spark.ml.regression.RandomForestRegressionModel;
import org.apache.spark.ml.regression.RandomForestRegressor;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;

public class RFRegression {

    public static void main(String[] args) throws Throwable {
      SparkSession session = SparkSession
        .builder()
        .master("local")
        .appName("JavaRandomForestRegressorExample")
        .getOrCreate();

      // $example on$
      // Load and parse the data file, converting it to a DataFrame.
      Dataset<Row> data = session.sqlContext().read().format("com.databricks.spark.csv").option("header", true).load("/home/shashank/SparkMLlib/Input/predit_BS.csv");
      //Dataset<Row> data = session.sqlContext().read().format("com.databricks.spark.csv").option("header", true).load("/home/shashank/SparkMLlib/Input/blood-sugar.csv");
      Dataset<Row> dataUp = data.withColumn("age",new Column("age").cast(DataTypes.DoubleType))
              .withColumn("Blood_suger",new Column("Blood_suger").cast(DataTypes.DoubleType))
              .withColumn("job",new Column("job").cast(DataTypes.StringType))
              .withColumn("marital",new Column("marital").cast(DataTypes.StringType));
      Dataset<Row> selectedData = dataUp.select("job","marital","Blood_suger","age");
      Dataset<Row> filteredData = selectedData.filter(new Column("job").notEqual(""));
      filteredData.show();
      final List<PipelineStage> pipelineStages = new ArrayList<PipelineStage>();
      selectedData.show();
      
      final List<String> continuous = new ArrayList<String>();
      continuous.add("age");
      continuous.add("Blood_suger")
      ;

      List<String> categorical = new ArrayList<String>();
      
      categorical.add("job");
      categorical.add("marital");
      
      List<String> assembleList = new ArrayList<String>();
      
      for (String variable : continuous) {
          assembleList.add(variable);
      }
      /*StringIndexer indexer1 = new StringIndexer().setInputCol("job")
              .setOutputCol("job" + "Indexer");
      Dataset<Row> dataindx1= indexer1.fit(filteredData).transform(filteredData);
      indexer1.fit(filteredData).transform(filteredData).show();
      
      StringIndexer indexer2 = new StringIndexer().setInputCol("marital")
              .setOutputCol("marital" + "Indexer");
      Dataset<Row> dataindx2= indexer2.fit(dataindx1).transform(dataindx1);
      
      OneHotEncoder encoder1 = new OneHotEncoder().setInputCol(
              "job" + "Indexer").setOutputCol("job" + "Encoder");
      Dataset<Row> dataenco1= encoder1.transform(dataindx2);
      
      OneHotEncoder encoder2 = new OneHotEncoder().setInputCol(
              "marital" + "Indexer").setOutputCol("marital" + "Encoder");
      Dataset<Row> dataenco2= encoder2.transform(dataenco1);*/
      
      String[] cols = {"job","marital","age","Blood_suger"};
      
      VectorAssembler assembler = new VectorAssembler();
      Dataset<Row> featuresDS=  assembler.setInputCols(cols)
              .setOutputCol("features")
              .transform(filteredData);
      
      RandomForestRegressionModel rfmodel= new RandomForestRegressor()
              .setLabelCol("Blood_suger")
              .setFeaturesCol("features")
              .fit(featuresDS);
      rfmodel.save("/home/shashank/SparkMLlib/Output/RFR/2");
      /*featuresDS.show();
      JavaRDD<Vector> vecRdd=  featuresDS.select("features").toJavaRDD().map(new Function<Row, Vector>() {

        @Override
        public Vector call(Row row) throws Exception {
            
            return (Vector) row.get(0);
        }
    });
    List <Vector> vecList = vecRdd.collect();
    RandomForestRegressionModel rfmdl = RandomForestRegressionModel.load("/home/shashank/SparkMLlib/Output/RFR/1");
    for(Vector vector :vecList){
       System.out.println(vector);
       System.out.println(rfmdl.predict(vector));  
    }*/ 
   

      session.stop();
    }

}
