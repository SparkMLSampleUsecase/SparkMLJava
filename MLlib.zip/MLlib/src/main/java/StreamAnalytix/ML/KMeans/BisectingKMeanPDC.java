package SampleML.ML.KMeans;

import java.io.IOException;
import java.util.List;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.ml.feature.CountVectorizer;
import org.apache.spark.ml.feature.CountVectorizerModel;
import org.apache.spark.ml.feature.RegexTokenizer;
import org.apache.spark.ml.feature.StopWordsRemover;
import org.apache.spark.ml.linalg.SparseVector;
import org.apache.spark.ml.clustering.BisectingKMeans;
import org.apache.spark.ml.clustering.BisectingKMeansModel;
import org.apache.spark.ml.linalg.Vector;
import org.apache.spark.ml.linalg.Vectors;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.api.java.UDF1;
import org.apache.spark.sql.types.ArrayType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import scala.collection.mutable.WrappedArray;

public class BisectingKMeanPDC {

    @SuppressWarnings("rawtypes")
    public static void pipelineExecuter(SparkSession session, String docsPath, String stopWordFile) throws IOException {
        JavaSparkContext jsc = JavaSparkContext.fromSparkContext(session.sparkContext());
        String path = docsPath;
        //Step -1 : Load all documents from directory
        JavaRDD<String> data = jsc.textFile(path, 4);
        //Step -2 : Regex tokenizor ,to generate tokens from lines
        StructType schema = new StructType(new StructField[] { new StructField("id", DataTypes.IntegerType, false, Metadata.empty()),
                new StructField("sentence", DataTypes.StringType, false, Metadata.empty()) });

        JavaRDD<Row> dataRow = data.map(new Function<String, Row>() {
            /**
             * 
             */
            private static final long serialVersionUID = 1649580279293882110L;
            int i = 1;

            @Override
            public Row call(String line) throws Exception {
                String lprossed = line.replaceAll("[^a-zA-Z0-9\\s]", "").trim();
                if (!"".equals(lprossed)) {
                    return RowFactory.create(i++, lprossed);
                } else {
                    return RowFactory.create(i++, "");
                }
            }

        });
        List<Row> dataList = dataRow.collect();
        Dataset<Row> documentDF = session.createDataFrame(dataList, schema);

        RegexTokenizer regexTokenizer = new RegexTokenizer().setInputCol("sentence").setOutputCol("words").setPattern("\\W"); // alternatively
                                                                                                                              // .setPattern("\\w+").setGaps(false);

        session.udf().register("countTokens", new UDF1<WrappedArray, Integer>() {
            /**
             * 
             */
            private static final long serialVersionUID = 9004272882316603588L;

            @Override
            public Integer call(WrappedArray words) {
                return words.size();
            }
        }, DataTypes.IntegerType);

        Dataset<Row> regexTokenized = regexTokenizer.transform(documentDF);
        //Step -3 : Stop word remover
        JavaRDD<String> stopWordsRDD = jsc.textFile(stopWordFile);
        List<String> stopWords = stopWordsRDD.collect();
        String[] stopWordArry = new String[stopWords.size()];
        int i = 0;
        for (String stopwrd : stopWords) {
            stopWordArry[i] = stopwrd.trim().toUpperCase();
            i++;
        }

        StopWordsRemover remover = new StopWordsRemover().setInputCol("raw").setOutputCol("filtered").setStopWords(stopWordArry);
        StructType sschema = new StructType(
                new StructField[] { new StructField("raw", DataTypes.createArrayType(DataTypes.StringType), false, Metadata.empty()) });
        List<Row> srdataList = regexTokenized.select("words").collectAsList();
        Dataset<Row> dataset = session.createDataFrame(srdataList, sschema);
        remover.transform(dataset).show(true);
        //Step -4 : fit a CountVectorizerModel from the corpus
        StructType vschema = new StructType(
                new StructField[] { new StructField("text", new ArrayType(DataTypes.StringType, false), false, Metadata.empty()) });
        List<Row> vdataList = remover.transform(dataset).select("filtered").collectAsList();
        Dataset<Row> vdocumentDF = session.createDataFrame(vdataList, vschema);
        CountVectorizerModel cvModel = new CountVectorizer().setInputCol("text").setOutputCol("features").setVocabSize(30000).setMinDF(2)
                .fit(vdocumentDF);
        cvModel.transform(vdocumentDF).show(true);
        /*JavaRDD<Vector> dataRDD = cvModel.transform(vdocumentDF).toJavaRDD().map(new Function<Row, Vector>() {

            *//**
             * 
             *//*
            private static final long serialVersionUID = 3999934922054010573L;

            @Override
            public Vector call(Row row) throws Exception {
                SparseVector svector = (SparseVector) row.get(1);
                Vector vector = Vectors.dense(svector.toDense().toArray());
                return vector;
            }

        });*/
        //Step -5 : Apply Bisecting K-Means algo. for clustering
        BisectingKMeans bkm = new BisectingKMeans()
                .setK(50)
                .setMaxIter(30)
                .setMinDivisibleClusterSize(10.0)
                .setSeed(45L);
        BisectingKMeansModel model = bkm.fit(cvModel.transform(vdocumentDF).select("features"));
        model.save("/home/shashank/SparkMLlib/Output/BKMModel/9");
        BisectingKMeansModel.load("/home/shashank/SparkMLlib/Output/BKMModel/9");
        cvModel.transform(vdocumentDF).select("features").toJavaRDD().saveAsTextFile("/home/shashank/SparkMLlib/Output/BKMModel/op/1");
        /*System.out.println("Compute Cost: " + model.computeCost(vdocumentDF));

        Vector[] clusterCenters = model.clusterCenters();
        for (int c = 0; c < clusterCenters.length; c++) {
            Vector clusterCenter = clusterCenters[c];
            System.out.println("Cluster Center " + c + ": " + clusterCenter);
        }*/
        jsc.stop();
    }

    public static void main(String[] args) throws IOException {
        SparkSession session = SparkSession.builder().appName("BisectingKmeanPipeline").master("local").getOrCreate();
        pipelineExecuter(session, "/home/shashank/SparkMLlib/Input/txtdocs/*", "/home/shashank/SparkMLlib/Input/stopwords-list.txt");

    }

}
