package SampleML.ML.KMeans;

import java.io.FileInputStream;
import java.util.Properties;

/**
 * @author shashank
 * Java class to load properties required for BiSecting K-Means algo.
 */
public class PropertyLoader {
    private PropertyLoader(){
        
    }
    private static Properties algoProperties;
    /**
     * Method to load property file
     * @param propertyFilePath
     * @return Properties
     * @throws Throwable
     */
    public static Properties loadProperty(String propertyFilePath) throws Throwable{
        if(algoProperties == null)
        {
            algoProperties = new Properties();
            algoProperties.load(new FileInputStream(propertyFilePath));;
        }
        return algoProperties;
    }

}
