package SampleML.ML.KMeans;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.ml.Pipeline;
import org.apache.spark.ml.PipelineModel;
import org.apache.spark.ml.PipelineStage;
import org.apache.spark.ml.clustering.KMeans;
import org.apache.spark.ml.clustering.KMeansModel;
import org.apache.spark.ml.feature.VectorAssembler;
import org.apache.spark.ml.linalg.Vector;
import org.apache.spark.ml.linalg.VectorUDT;
import org.apache.spark.ml.linalg.Vectors;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

public class KmeanPipelineStudentGrage2 {

    public static void main(String[] args) {
        // Create a SparkSession.
           SparkSession spark = SparkSession
             .builder().master("local")
             .appName("JavaKMeansExample")
             .getOrCreate();
           String path = "/home/shashank/SparkMLlib/Input/studentData1.txt";
           System.out.println("path:"+path);
           JavaSparkContext jsc = JavaSparkContext.fromSparkContext(spark.sparkContext());
           // Loads data.
           JavaRDD<String> dataRDD = jsc.textFile(path)
                   .map(new Function<String, String>() {

               public String call(String line) throws Exception {
                   return line.trim();
               }
           });
           
           
           
           JavaRDD<Row> dataRow = dataRDD.map(new Function<String,Row>(){

               public Row call(String line) throws Exception {
                   String[] sarray = line.split(" ");
                   double[] values = new double[sarray.length];
                   for (int i = 0; i < sarray.length; i++) {
                      if(i>0) {
                       values[i] = Double.parseDouble(sarray[i]);
                      }
                   }
                   Row r= RowFactory.create(Integer.parseInt(sarray[0]),
                           Integer.parseInt(sarray[1]),
                           Integer.parseInt(sarray[2]),
                           Integer.parseInt(sarray[3]),
                           Integer.parseInt(sarray[4]));
                   return r;
               }
               
           });
           
           StructType schema = new StructType(
                   new StructField[]{
                           new StructField("id", DataTypes.IntegerType, true,Metadata.empty()),
                           new StructField("english", DataTypes.IntegerType, true,Metadata.empty()),
                           new StructField("maths", DataTypes.IntegerType, true,Metadata.empty()),
                           new StructField("physics", DataTypes.IntegerType, true,Metadata.empty()),
                           new StructField("computer", DataTypes.IntegerType, true,Metadata.empty())
                           });
           Dataset<Row> dataset = spark.createDataFrame(dataRow, schema);
           dataset.show();
           
           final List<String> continuous = new ArrayList<String>();
           continuous.add("english");
           continuous.add("maths");
           continuous.add("physics");
           continuous.add("computer");
           
           List<String> assembleList = new ArrayList<String>();
           List<PipelineStage> pipelineStages = new ArrayList<PipelineStage>();
           for (String variable : continuous) {
               assembleList.add(variable);
           }
           
           VectorAssembler assembler = new VectorAssembler();
           assembler.setInputCols(///
                   assembleList.toArray(new String[assembleList.size()]))
                   .setOutputCol("features");
           pipelineStages.add(assembler);
           
           
           
          
           KMeans kmeans = new KMeans().setK(4).setSeed(1L).setPredictionCol("Prediction");
           
           pipelineStages.add(kmeans);
           Pipeline pipeline = new Pipeline();
           
           
           pipeline.setStages(pipelineStages
                   .toArray(new PipelineStage[pipelineStages.size()]));
           
           PipelineModel pipemodel = pipeline.fit(dataset);
           
           dataset = pipemodel.transform(dataset);
           System.out.println("pipeline:::");
           dataset.show();
           
           try {
               pipemodel.save("/home/shashank/Desktop/kmeans");
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
           KMeansModel model = (KMeansModel)pipemodel.stages()[pipelineStages.size()-1];
           
           
           // Evaluate clustering by computing Within Set Sum of Squared Errors.
           double WSSSE = model.computeCost(dataset);
           System.out.println("Within Set Sum of Squared Errors = " + WSSSE);
           
           // Shows the result.
           Vector[] centers = model.clusterCenters();
           System.out.println("Cluster Centers: ");
           int i=0;
           for (Vector center: centers) {
             System.out.println(i++ + "count :"+center);
           }
           

       }
}
