package SampleML.ML.KMeans;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.ml.Pipeline;
import org.apache.spark.ml.PipelineStage;
import org.apache.spark.ml.clustering.BisectingKMeans;
import org.apache.spark.ml.feature.RegexTokenizer;
import org.apache.spark.ml.feature.StopWordsRemover;
import org.apache.spark.ml.feature.Word2Vec;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

public class BisectingKMeanPipeline {

    /** Pipeline preparation and execution
     * 
     * @param session
     * @param docsPath
     * @param stopWordFile
     * @throws IOException */
    public static void executer(SparkSession session, String docsPath, String stopWordFile) throws IOException {
        JavaSparkContext jsc = JavaSparkContext.fromSparkContext(session.sparkContext());
        String path = docsPath;
        JavaRDD<String> data = jsc.textFile(path, 4);
        JavaRDD<String> stopWordsRDD = jsc.textFile(stopWordFile);
        List<String> stopWords = stopWordsRDD.collect();
        String[] stopWordArry = new String[stopWords.size()];
        int i = 0;
        for (String stopwrd : stopWords) {
            stopWordArry[i] = stopwrd.trim().toUpperCase();
            i++;
        }
        // Regex tokenizor
        StructType schema = new StructType(new StructField[] { new StructField("id", DataTypes.IntegerType, false, Metadata.empty()),
                new StructField("sentence", DataTypes.StringType, false, Metadata.empty()) });

        JavaRDD<Row> dataRow = data.map(new Function<String, Row>() {
            /**
             * 
             */
            private static final long serialVersionUID = 1L;
            int i = 1;

            @Override
            public Row call(String line) throws Exception {
                String lprossed = line.replaceAll("[^a-zA-Z0-9\\s]", "").trim();
                if (!"".equals(lprossed)) {
                    return RowFactory.create(i++, lprossed);
                } else {
                    return RowFactory.create(i++, "");
                }
            }

        });
        List<Row> dataList = dataRow.takeSample(false, 20000);
        Dataset<Row> documentDF = session.createDataFrame(dataList, schema);
        RegexTokenizer regexTokenizer = new RegexTokenizer().setInputCol("sentence").setOutputCol("words").setPattern("\\W"); // alternatively
        // Stop word remover
        StopWordsRemover remover = new StopWordsRemover().setInputCol("words").setOutputCol("filtered").setStopWords(stopWordArry);
        // Vector generation with counting number of words
        Word2Vec w2v = new Word2Vec().setInputCol("filtered").setOutputCol("feature").setMaxIter(20).setMaxSentenceLength(2000).setMinCount(1)
                .setNumPartitions(4).setSeed(1L).setStepSize(3.0).setVectorSize(1000).setWindowSize(900);
        // Creation of BisectingKMeans algo. parameters
        BisectingKMeans bkm = new BisectingKMeans().setK(4).setFeaturesCol("feature").setPredictionCol("prediction").setMaxIter(20)
                .setMinDivisibleClusterSize(2).setSeed(1L);
        // Setting up stages of pipeline
        List<PipelineStage> pipelineStages = new ArrayList<PipelineStage>();
        pipelineStages.add(regexTokenizer);
        pipelineStages.add(remover);
        pipelineStages.add(w2v);
        pipelineStages.add(bkm);
        // Creation of pipeline
        Pipeline pipeline = new Pipeline().setStages(pipelineStages.toArray(new PipelineStage[pipelineStages.size()]));
        // execution of pipeline
        pipeline.fit(documentDF).save("/home/shashank/SparkMLlib/Output/pipeline/2");
        /*Dataset ds = pipeline.fit(documentDF).transform(documentDF).select("feature");
        ds.toJavaRDD().saveAsTextFile("/home/shashank/SparkMLlib/Output/5/");*/
        // Evaluate clustering by computing Within Set Sum of Squared Errors

       /* BisectingKMeansModel bkmdl = bkm.fit(pipeline.fit(documentDF).transform(documentDF).select("feature"));
        double WSSSE = bkmdl.computeCost(pipeline.fit(documentDF).transform(documentDF).select("feature"));
        System.out.println("Within Set Sum of Squared Errors = " + WSSSE);*/
        //BisectingKMeansModel bkmdl2 = BisectingKMeansModel.load("/home/shashank/SparkMLlib/Input/stopwords-list.txt");
        //System.out.println("Params = " + bkmdl2.explainParams());
        
        jsc.stop();
    }

    public static void main(String[] args) throws IOException {
        SparkSession session = SparkSession.builder().appName("BisectingKmeanPipeline").master("local").getOrCreate();
        executer(session, "/home/shashank/SparkMLlib/Input/txtdocs/*", "/home/shashank/SparkMLlib/Input/stopwords-list.txt");
    }

}
