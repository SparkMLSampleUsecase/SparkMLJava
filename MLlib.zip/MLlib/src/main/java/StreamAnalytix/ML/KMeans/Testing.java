package SampleML.ML.KMeans;

public class Testing {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        //System.out.println("MY 1 firest*w program.'".replaceAll("[^a-zA-Z0-9\\s]",""));
        System.out.println(new Integer(""));
    }

}
