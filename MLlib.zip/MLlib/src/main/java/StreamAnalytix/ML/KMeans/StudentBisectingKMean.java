package SampleML.ML.KMeans;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.ml.clustering.BisectingKMeans;
import org.apache.spark.ml.clustering.BisectingKMeansModel;
import org.apache.spark.ml.feature.VectorAssembler;
import org.apache.spark.ml.linalg.Vector;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.json.JSONObject;

public class StudentBisectingKMean {

    @SuppressWarnings("rawtypes")
    public static void pipelineExecuter(SparkSession session, String inputPath) throws IOException {
        JavaSparkContext jsc = JavaSparkContext.fromSparkContext(session.sparkContext());
        String path = inputPath;
        // Step -1 : Load all documents from directory
        JavaRDD<String> data = jsc.textFile(path, 4);
        JavaRDD<Row> dataParsd = data.map(new Function<String,Row>(){

            /**
             * 
             */
            private static final long serialVersionUID = 1L;

            public Row call(String line) throws Exception {
                String[] sarray = line.split(" ");
                double[] values = new double[sarray.length];
                for (int i = 0; i < sarray.length; i++) {
                   if(i>0) {
                       if(sarray[i].matches("^[a-zA-Z]*$")){
                           System.out.println(sarray[i]);
                       }
                       else{
                           values[i] = Double.parseDouble(sarray[i]);
                       }
                   }
                }
                Row r= RowFactory.create(Integer.parseInt(sarray[0]),
                        Integer.parseInt(sarray[1]),
                        Integer.parseInt(sarray[2]),
                        Integer.parseInt(sarray[3]),
                        Integer.parseInt(sarray[4]));
                return r;
            }
            
        });
        
        StructType schema = new StructType(
                new StructField[]{
                        new StructField("id", DataTypes.IntegerType, true,Metadata.empty()),
                        new StructField("english", DataTypes.IntegerType, true,Metadata.empty()),
                        new StructField("maths", DataTypes.IntegerType, true,Metadata.empty()),
                        new StructField("physics", DataTypes.IntegerType, true,Metadata.empty()),
                        new StructField("computer", DataTypes.IntegerType, true,Metadata.empty())
                        });

        List<Row> dataList = dataParsd.collect();
        Dataset<Row> studentDF = session.createDataFrame(dataList, schema);
        final List<String> continuous = new ArrayList<String>();
        continuous.add("english");
        continuous.add("maths");
        continuous.add("physics");
        continuous.add("computer");
        
        List<String> assembleList = new ArrayList<String>();
        for (String variable : continuous) {
            assembleList.add(variable);
        }
        
        VectorAssembler assembler = new VectorAssembler();
        assembler.setInputCols(///
                assembleList.toArray(new String[assembleList.size()]))
                .setOutputCol("features");
        
       Dataset<Row> assembledDS= assembler.transform(studentDF);

        // wvModel.transform(vdocumentDF).select("features").toJavaRDD().saveAsTextFile("/home/shashank/SparkMLlib/Output/Features/7");
        // Step -5 : Apply Bisecting K-Means algo. for clustering
        BisectingKMeans bkm = new BisectingKMeans().setK(5).setMaxIter(30).setMinDivisibleClusterSize(2.0).setSeed(1L);
        BisectingKMeansModel model = bkm.fit(assembledDS.select("features"));
        Vector[] clusterCenters = model.clusterCenters();
        bkm.fit(assembledDS.select("features")).transform(assembledDS.select("features")).toJavaRDD()
                .saveAsTextFile("/home/shashank/SparkMLlib/Output/BKMModel/op/" + System.currentTimeMillis());
        List<Row> groupCoordinates = bkm.fit(assembledDS.select("features")).transform(assembledDS.select("features")).toJavaRDD().collect();
        JSONObject obj = null;
        List<JSONObject> jsonData = new ArrayList<JSONObject>();
        System.out.println("X,Y");
        int cent = 0;
        Map<String, String> datapoints = null;
        Map<String, List<Map>> dataMap = new HashMap<String, List<Map>>();
        List<Map> dataListMap = new ArrayList<Map>();
        for (Row grpCordi : groupCoordinates) {
            String[] coordi = (grpCordi.get(0).toString().replace("[", "").replace("]", "")).split(",");
            // System.out.println("X : " +coordi[0]+ " Y :" +coordi[1]+" Cluster :" +grpCordi.get(1).toString());
            if (null != dataMap.get(grpCordi.get(1).toString())) {
                dataListMap = dataMap.get(grpCordi.get(1).toString());
            }
            datapoints = new HashMap<String, String>();
            datapoints.put("X", coordi[0]);
            datapoints.put("Y", coordi[1]);
            dataListMap.add(datapoints);
            dataMap.put(grpCordi.get(1).toString(), dataListMap);
            
            // System.out.println("["+coordi[0]+ "," +coordi[1]+"]");
        }
        for(int cnt=0; cnt < dataMap.size(); cnt++){
            
            obj = new JSONObject();
            String clusterNumber =new Integer(cnt).toString();
            obj.put("cluster", clusterNumber);
            obj.put("cluster_coordinates", clusterCenters[cnt]);
            obj.put("data_coordinates", dataMap.get(clusterNumber));
            
            jsonData.add(obj);
        }
        for (JSONObject json : jsonData) {
            System.out.println(json);
        }
        // System.out.println("********************" + dataMap.entrySet());
        // System.out.println("ClusterCenters count " + model.clusterCenters().length);
        int count = 0;
        for (Vector vector : clusterCenters) {
            System.out.println("ClusterCenter " + count + " :: " + vector.toString());
            count++;
        }
        // model.save("/home/shashank/SparkMLlib/Output/BKMModel/19");
        // BisectingKMeansModel.load("/home/shashank/SparkMLlib/Output/BKMModel/19");
        // scalerModel.transform(vecDataSet).select("features").toJavaRDD().saveAsTextFile("/home/shashank/SparkMLlib/Output/BKMModel/op/"+System.currentTimeMillis());

        /*
         * System.out.println("Compute Cost: " + model.computeCost(vdocumentDF)); Vector[] clusterCenters = model.clusterCenters(); for (int c = 0; c
         * < clusterCenters.length; c++) { Vector clusterCenter = clusterCenters[c]; System.out.println("Cluster Center " + c + ": " + clusterCenter);
         * }
         */
        jsc.stop();
    }

    public static void main(String[] args) throws IOException {
        SparkSession session = SparkSession.builder().appName("BisectingKmeanPipeline").master("local").getOrCreate();
        pipelineExecuter(session,  "/home/shashank/SparkMLlib/Input/studentData1.txt");

    }

}
