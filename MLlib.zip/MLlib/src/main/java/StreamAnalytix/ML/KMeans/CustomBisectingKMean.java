package SampleML.ML.KMeans;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.ml.clustering.BisectingKMeans;
import org.apache.spark.ml.clustering.BisectingKMeansModel;
import org.apache.spark.ml.feature.MinMaxScaler;
import org.apache.spark.ml.feature.MinMaxScalerModel;
import org.apache.spark.ml.feature.RegexTokenizer;
import org.apache.spark.ml.feature.StopWordsRemover;
import org.apache.spark.ml.feature.Word2Vec;
import org.apache.spark.ml.feature.Word2VecModel;
import org.apache.spark.ml.linalg.Vector;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.api.java.UDF1;
import org.apache.spark.sql.types.ArrayType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.json.JSONObject;

import scala.collection.mutable.WrappedArray;

public class CustomBisectingKMean {

    @SuppressWarnings("rawtypes")
    public static void pipelineExecuter(SparkSession session, String docsPath, String stopWordFile) throws IOException {
        JavaSparkContext jsc = JavaSparkContext.fromSparkContext(session.sparkContext());
        String path = docsPath;
        // Step -1 : Load all documents from directory
        JavaRDD<String> data = jsc.textFile(path, 4);
        // Step -2 : Regex tokenizor ,to generate tokens from lines
        StructType schema = new StructType(new StructField[] { new StructField("id", DataTypes.IntegerType, false, Metadata.empty()),
                new StructField("sentence", DataTypes.StringType, false, Metadata.empty()) });

        JavaRDD<Row> dataRow = data.map(new Function<String, Row>() {
            /**
             * 
             */
            private static final long serialVersionUID = 1649580279293882110L;
            int i = 1;

            @Override
            public Row call(String line) throws Exception {
                String lprossed = line.replaceAll("[^a-zA-Z0-9\\s]", "").trim();
                if (!"".equals(lprossed)) {
                    return RowFactory.create(i++, lprossed);
                } else {
                    return RowFactory.create(i++, "");
                }
            }

        });
        List<Row> dataList = dataRow.collect();
        Dataset<Row> documentDF = session.createDataFrame(dataList, schema);

        RegexTokenizer regexTokenizer = new RegexTokenizer().setInputCol("sentence").setOutputCol("words").setPattern("\\W"); // alternatively
                                                                                                                              // .setPattern("\\w+").setGaps(false);

        session.udf().register("countTokens", new UDF1<WrappedArray, Integer>() {
            /**
             * 
             */
            private static final long serialVersionUID = 9004272882316603588L;

            @Override
            public Integer call(WrappedArray words) {
                return words.size();
            }
        }, DataTypes.IntegerType);

        Dataset<Row> regexTokenized = regexTokenizer.transform(documentDF);
        // Step -3 : Stop word remover
        JavaRDD<String> stopWordsRDD = jsc.textFile(stopWordFile);
        List<String> stopWords = stopWordsRDD.collect();
        String[] stopWordArry = new String[stopWords.size()];
        int i = 0;
        for (String stopwrd : stopWords) {
            stopWordArry[i] = stopwrd.trim().toUpperCase();
            i++;
        }

        StopWordsRemover remover = new StopWordsRemover().setInputCol("raw").setOutputCol("filtered").setStopWords(stopWordArry);
        StructType sschema = new StructType(
                new StructField[] { new StructField("raw", DataTypes.createArrayType(DataTypes.StringType), false, Metadata.empty()) });
        List<Row> srdataList = regexTokenized.select("words").collectAsList();
        Dataset<Row> dataset = session.createDataFrame(srdataList, sschema);
        remover.transform(dataset).show(true);

        // Step -4 : fit a Word to vec from the corpus
        StructType vschema = new StructType(
                new StructField[] { new StructField("filtered", new ArrayType(DataTypes.StringType, false), false, Metadata.empty()) });
        List<Row> vdataList = remover.transform(dataset).select("filtered").collectAsList();
        Dataset<Row> vdocumentDF = session.createDataFrame(vdataList, vschema);

        /*
         * CountVectorizerModel cvModel = new CountVectorizer().setInputCol("text").setOutputCol("features").setVocabSize(30000).setMinDF(2)
         * .fit(vdocumentDF);
         */
        Word2VecModel wvModel = new Word2Vec().setMaxIter(20).setMaxSentenceLength(200).setMinCount(1).setNumPartitions(2).setSeed(1L)
                .setStepSize(3.0).setVectorSize(2).setWindowSize(20).setInputCol("filtered").setOutputCol("vecfeatures").fit(vdocumentDF);

        Dataset<Row> vecDataSet = wvModel.transform(vdocumentDF).select("vecfeatures");

        MinMaxScaler scaler = new MinMaxScaler().setInputCol("vecfeatures").setOutputCol("features").setMax(3.0).setMin(-3.0);

        // Compute summary statistics and generate MinMaxScalerModel
        MinMaxScalerModel scalerModel = scaler.fit(vecDataSet);

        // rescale each feature to range [min, max].
        Dataset<Row> scaledData = scalerModel.transform(vecDataSet);
        scaledData.show(true);

        // wvModel.transform(vdocumentDF).select("features").toJavaRDD().saveAsTextFile("/home/shashank/SparkMLlib/Output/Features/7");
        // Step -5 : Apply Bisecting K-Means algo. for clustering
        BisectingKMeans bkm = new BisectingKMeans().setK(5).setMaxIter(30).setMinDivisibleClusterSize(2.0).setSeed(1L);
        BisectingKMeansModel model = bkm.fit(scaledData.select("features"));
        Vector[] clusterCenters = model.clusterCenters();
        bkm.fit(scaledData.select("features")).transform(scaledData.select("features")).toJavaRDD()
                .saveAsTextFile("/home/shashank/SparkMLlib/Output/BKMModel/op/" + System.currentTimeMillis());
        List<Row> groupCoordinates = bkm.fit(scaledData.select("features")).transform(scaledData.select("features")).toJavaRDD().collect();
        JSONObject obj = null;
        List<JSONObject> jsonData = new ArrayList<JSONObject>();
        System.out.println("X,Y");
        int cent = 0;
        Map<String, String> datapoints = null;
        Map<String, List<Map>> dataMap = new HashMap<String, List<Map>>();
        List<Map> dataListMap = new ArrayList<Map>();
        for (Row grpCordi : groupCoordinates) {
            String[] coordi = (grpCordi.get(0).toString().replace("[", "").replace("]", "")).split(",");
            // System.out.println("X : " +coordi[0]+ " Y :" +coordi[1]+" Cluster :" +grpCordi.get(1).toString());
            if (null != dataMap.get(grpCordi.get(1).toString())) {
                dataListMap = dataMap.get(grpCordi.get(1).toString());
            }
            datapoints = new HashMap<String, String>();
            datapoints.put("X", coordi[0]);
            datapoints.put("Y", coordi[1]);
            dataListMap.add(datapoints);
            dataMap.put(grpCordi.get(1).toString(), dataListMap);
            
            // System.out.println("["+coordi[0]+ "," +coordi[1]+"]");
        }
        for(int cnt=0; cnt < dataMap.size(); cnt++){
            
            obj = new JSONObject();
            String clusterNumber =new Integer(cnt).toString();
            obj.put("cluster", clusterNumber);
            obj.put("cluster_coordinates", clusterCenters[cnt]);
            obj.put("data_coordinates", dataMap.get(clusterNumber));
            
            jsonData.add(obj);
        }
        for (JSONObject json : jsonData) {
            System.out.println(json);
        }
        // System.out.println("********************" + dataMap.entrySet());
        // System.out.println("ClusterCenters count " + model.clusterCenters().length);
        int count = 0;
        for (Vector vector : clusterCenters) {
            System.out.println("ClusterCenter " + count + " :: " + vector.toString());
            count++;
        }
        // model.save("/home/shashank/SparkMLlib/Output/BKMModel/19");
        // BisectingKMeansModel.load("/home/shashank/SparkMLlib/Output/BKMModel/19");
        // scalerModel.transform(vecDataSet).select("features").toJavaRDD().saveAsTextFile("/home/shashank/SparkMLlib/Output/BKMModel/op/"+System.currentTimeMillis());

        /*
         * System.out.println("Compute Cost: " + model.computeCost(vdocumentDF)); Vector[] clusterCenters = model.clusterCenters(); for (int c = 0; c
         * < clusterCenters.length; c++) { Vector clusterCenter = clusterCenters[c]; System.out.println("Cluster Center " + c + ": " + clusterCenter);
         * }
         */
        jsc.stop();
    }

    public static void main(String[] args) throws IOException {
        SparkSession session = SparkSession.builder().appName("BisectingKmeanPipeline").master("local").getOrCreate();
        pipelineExecuter(session, "/home/shashank/SparkMLlib/Input/txtdocs/*", "/home/shashank/SparkMLlib/Input/stopwords-list.txt");

    }

}
