package SampleML.ML.test;

public class MLlibConstants {
    public static final String SPARK_MLLIB = "SPARK_MLLIB";
    public static String USE_SAVED_MODEL = "USE_SAVED_MODEL";
    public static final String SPARK_ML = "SPARK_ML";
    public static final String CONTINUOUS_VARIABLES = "continuous_variable";
    public static final String CATEGORICAL_VARIABLES = "categorical_variable";
    
    public static final String RFR_MODEL_PATH = "/home/shashank/SparkMLlib/Output/RFR/10";
    public static final String TREE = "tree";
    
    public static final String PIPELINE_MODEL_PATH = "/home/hduser/SampleML/test/pipelinemodel";
    public static final String INDIVIDUAL_MODEL_PATH = "/home/hduser/SampleML/testing/simplemodel";
    
    
    public static final String REGRESSION_PIPELINE_MODEL_PATH = "/home/hduser/SampleML/test/regression/pipelinemodel";
    public static final String REGRESSION_INDIVIDUAL_MODEL_PATH = "/home/hduser/SampleML/testing/regression/simplemodel";
    public static final String ID = "id";
    public static final String IMPURITY = "impurity";
    public static final String PROBABILITY = "probabilty";
    public static final String IS_LEAF_NODE = "isleafNode";
    
    
    
    public static final String SCORE = "score";
    
    public static final int HUNDRED = 100;
    public static final int TEN_THOUSAND = 10000;
    
    public static final String PERCENTAGE = "%";
    
    public static final String PARENT = "parent";
    public static final String CHILDREN = "children";
    public static final String EMPTY_STRING = "";
    public static final String RULE = "rule";
    public static final String TREE_DEPTH = "tree_depth";
    public static final String WEIGHT = "weight";
    
    
    public static final String LESS_THAN_EQUAL_TO = "<=";
    public static final String GREATER_THAN = ">";
    
    public static final String IN = "in";
    public static final String NOT_IN = "not in";

}
