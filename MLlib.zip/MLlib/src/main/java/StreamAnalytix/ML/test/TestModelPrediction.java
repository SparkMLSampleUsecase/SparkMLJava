package SampleML.ML.test;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.spark.ml.PipelineModel;
import org.apache.spark.ml.clustering.BisectingKMeansModel;
import org.apache.spark.ml.clustering.GaussianMixtureModel;
import org.apache.spark.ml.linalg.Vectors;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.ml.regression.RandomForestRegressionModel;

public class TestModelPrediction {

    /** @param session
     * @param modelPath
     * @param modelType
     * @param configObject
     * @param testData
     * @param modelAPI
     * @param tenantId
     * @return predections
     * @throws Exception */
    public static Object testMLlibModel(SparkSession session, String modelPath, String modelType,
            Map<String, Object> configObject, Map<String, Object> testData, String modelAPI, String tenantId) throws Exception {
        Object model = null;
        String[] predictons = null;
        System.out.println("Model is of type " + modelAPI);

        boolean useSavedModel = Boolean.parseBoolean(configObject.get(MLlibConstants.USE_SAVED_MODEL).toString());
        if (useSavedModel) {
            Method method = Class.forName(modelType).getMethod("load", String.class);
            model = method.invoke(null, modelPath);
        } else {
            // create model
            /* model = createModelByType(modelType, configObject); */
        }

        if (model != null) {
            if (modelAPI.equalsIgnoreCase(MLlibConstants.SPARK_MLLIB)) {

            } else if (modelAPI.equalsIgnoreCase(MLlibConstants.SPARK_ML)) {
                
                if (model instanceof org.apache.spark.ml.clustering.BisectingKMeansModel) {
                    predictons = new String[testData.size()];
                    int cnt = 0;
                    for(Object vec : testData.values()){
                        String []vecVals = vec.toString().split(",");
                        double [] vals = new double[vecVals.length];
                        for(int c=0;c<vecVals.length;c++)
                        {
                            vals[c] =  Double.parseDouble(vecVals[c]);
                            
                        }
                        predictons[cnt]=""+((BisectingKMeansModel)model).predict(Vectors.dense(vals));
                        System.out.println(predictons[cnt]);
                        cnt++;
                    }
                }
                else if(model instanceof org.apache.spark.ml.clustering.GaussianMixtureModel){
                    predictons = new String[testData.size()];
                    int cnt = 0;
                    for(Object vec : testData.values()){
                        String []vecVals = vec.toString().split(",");
                        double [] vals = new double[vecVals.length];
                        for(int c=0;c<vecVals.length;c++)
                        {
                            vals[c] =  Double.parseDouble(vecVals[c]);
                        }
                        predictons[cnt]=""+((GaussianMixtureModel)model).predict(Vectors.dense(vals));
                        System.out.println(predictons[cnt]);
                        cnt++;
                    }
                }
                else if(model instanceof org.apache.spark.ml.regression.RandomForestRegressionModel){
                    predictons = new String[testData.size()];
                    int cnt = 0;
                    for(Object vec : testData.values()){
                        String []vecVals = vec.toString().split(",");
                        double [] vals = new double[vecVals.length];
                        for(int c=0;c<vecVals.length;c++)
                        {
                            vals[c] =  Double.parseDouble(vecVals[c]);
                        }
                        predictons[cnt]=""+((RandomForestRegressionModel)model).predict(Vectors.dense(vals));
                        System.out.println(predictons[cnt]);
                        cnt++;
                    }
                }
                else if (model instanceof org.apache.spark.ml.PipelineModel) {
                    StructField[] fields= new StructField[testData.keySet().size()];
                    int cnt = 0;
                    for(String collabel : testData.keySet()){
                        if(testData.get(collabel).getClass().getSimpleName().equalsIgnoreCase("Integer")){
                            fields[cnt]=new StructField(collabel, DataTypes.IntegerType, false, Metadata.empty()); 
                        }
                        else if(testData.get(collabel).getClass().getSuperclass().getSimpleName().equalsIgnoreCase("Number")){
                            fields[cnt]=new StructField(collabel, DataTypes.DoubleType, false, Metadata.empty()); 
                        }
                        else{
                            fields[cnt]=new StructField(collabel, DataTypes.StringType, false, Metadata.empty());
                        }
                        
                        cnt++;
                    }
                    StructType schema = new StructType(fields);
                    List<Row> dataList = Arrays.asList(RowFactory.create(testData.values().toArray()));
                    
                    Dataset<Row> documentDF = session.createDataFrame(dataList, schema);
                    documentDF.show();
                    List<Row> predictionList = ((PipelineModel) model).transform(documentDF).select("prediction").collectAsList();
                    ((PipelineModel) model).transform(documentDF).show();
                    predictons = new String[predictionList.size()];
                    System.out.println("Pipeline model predections");
                    int count = 0;
                    for (Row predection : predictionList) {
                        predictons[count] = ""+predection.get(0);
                        System.out.println(predictons[count]);
                        count++;
                    }

                }
            }
        }
        return predictons;
    }

    public static void main(String[] args) throws Exception {
        SparkSession session = SparkSession.builder().appName("ModelTest").master("local").getOrCreate();
        Map<String, Object> configObject = new HashMap<String, Object>();
        configObject.put(MLlibConstants.USE_SAVED_MODEL, true);
        Map<String, Object> testDataSVM = new HashMap<String, Object>();
        testDataSVM.put("svm1", "0.0,0.0,0.0");
        testDataSVM.put("svm2", "0.1,0.1,0.1");
        testDataSVM.put("svm3", "0.2,0.2,0.2");
        testDataSVM.put("svm4", "9.0,9.0,9.0");
        testDataSVM.put("svm5", "9.1,9.1,9.1");
        testDataSVM.put("svm6", "9.2,9.2,9.2");
        Map<String, Object> testDataSVMRF = new HashMap<String, Object>();
        testDataSVMRF.put("svm1", "0.0,0.0,0.0,0.0");
        testDataSVMRF.put("svm2", "0.1,0.1,0.1,0.0");
        testDataSVMRF.put("svm3", "0.2,0.2,0.2,0.0");
        testDataSVMRF.put("svm4", "9.0,9.0,9.0,0.0");
        testDataSVMRF.put("svm5", "9.1,9.1,9.1,1.0");
        testDataSVMRF.put("svm6", "9.2,9.2,9.2,1.0");
        
        Map<String, Object> testDataBKM = new HashMap<String, Object>();
        testDataBKM.put("sentence", "Intuitionist definitions, developing from " + "the philosophy of mathematician L.E.J. Brouwer, "
                + "identify mathematics with certain mental phenomena." + " An example of an intuitionist definition is "
                + "'Mathematics is the mental activity which consists in carrying out "
                + "constructs one after the other.'[30] A peculiarity of intuitionism"
                + " is that it rejects some mathematical ideas considered valid " + "according to other definitions. In particular, "
                + "while other philosophies of mathematics allow objects " + "that can be proved to exist even though they cannot be constructed, "
                + "intuitionism allows only mathematical objects that one can actually "
                + "construct.Formalist definitions identify mathematics with its symbols " + "and the rules for operating on them. "
                + "Haskell Curry defined mathematics simply as " + "'the science of formal systems'.[33] "
                + "A formal system is a set of symbols, or tokens, " + "and some rules telling how the tokens may be combined into formulas. "
                + "In formal systems, the word axiom has a special meaning, different "
                + "from the ordinary meaning of 'a self-evident truth'. In formal systems, "
                + "an axiom is a combination of tokens that is included in a given "
                + "formal system without needing to be derived using the rules of the system.");
        
        Map<String, Object> testDataGMM = new HashMap<String, Object>();
        testDataGMM.put("Area_in_km_sqr",200000.0);
        testDataGMM.put("Population", 60000.0);
        
        Map<String, Object> testDataRFR = new HashMap<String, Object>();
        testDataRFR.put("age",81.0);
        testDataRFR.put("Blood_suger",0.0);
        testDataRFR.put("job","management");
        testDataRFR.put("marital", "married");
        
        Map<String, Object> testDataRFC = new HashMap<String, Object>();
        testDataRFC.put("PassengerId",103);
        testDataRFC.put("Survived",0);
        testDataRFC.put("Pclass",1);
        testDataRFC.put("Sex", "male");
        testDataRFC.put("Age", 21);
        testDataRFC.put("SibSp", 0);
        testDataRFC.put("Parch", 1);
        testDataRFC.put("Fare", 77);
        testDataRFC.put("Embarked", "S");
        testDataRFC.put("Title","Mr");
        testDataRFC.put("Family",1);
        
        testMLlibModel(session, "/home/shashank/SparkMLlib/Output/BKMModel/16", "org.apache.spark.ml.clustering.BisectingKMeansModel", configObject,
                testDataSVM, MLlibConstants.SPARK_ML, null);
        testMLlibModel(session, "/home/shashank/SparkMLlib/Output/GMM/1", "org.apache.spark.ml.clustering.GaussianMixtureModel", configObject,
                testDataSVM, MLlibConstants.SPARK_ML, null);
        testMLlibModel(session, "/home/shashank/SparkMLlib/Output/pipeline/2", "org.apache.spark.ml.PipelineModel", configObject, testDataBKM,
                MLlibConstants.SPARK_ML, null);
        testMLlibModel(session, "/home/shashank/SparkMLlib/Output/pipeline/GMM/4", "org.apache.spark.ml.PipelineModel", configObject, testDataGMM,
                MLlibConstants.SPARK_ML, null);
        testMLlibModel(session, "/home/shashank/SparkMLlib/Output/RFR/10", "org.apache.spark.ml.regression.RandomForestRegressionModel", configObject,
                testDataSVMRF, MLlibConstants.SPARK_ML, null);
        testMLlibModel(session, "/home/shashank/SparkMLlib/Output/RFR/PL/3", "org.apache.spark.ml.PipelineModel", configObject, testDataRFR,
                MLlibConstants.SPARK_ML, null);
        testMLlibModel(session, "/home/shashank/SparkMLlib/Output/RFC/RFClassification", "org.apache.spark.ml.PipelineModel", configObject, testDataRFC,
                MLlibConstants.SPARK_ML, null);
    }

}
